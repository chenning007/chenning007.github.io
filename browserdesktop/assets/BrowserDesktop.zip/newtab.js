// Default 4K image - a beautiful gradient landscape
const DEFAULT_IMAGE = `data:image/svg+xml,<svg width="3840" height="2160" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%"><stop offset="0%" style="stop-color:%231e3c72;stop-opacity:1"/><stop offset="50%" style="stop-color:%232a5298;stop-opacity:1"/><stop offset="100%" style="stop-color:%237e8ba3;stop-opacity:1"/></linearGradient><linearGradient id="mountain1" x1="0%" y1="0%" x2="0%" y2="100%"><stop offset="0%" style="stop-color:%232d3561;stop-opacity:1"/><stop offset="100%" style="stop-color:%231a1f3a;stop-opacity:1"/></linearGradient><linearGradient id="mountain2" x1="0%" y1="0%" x2="0%" y2="100%"><stop offset="0%" style="stop-color:%233d4574;stop-opacity:1"/><stop offset="100%" style="stop-color:%23252b4a;stop-opacity:1"/></linearGradient></defs><rect width="3840" height="2160" fill="url(%23sky)"/><circle cx="3200" cy="400" r="200" fill="%23ffd700" opacity="0.3"/><circle cx="3200" cy="400" r="120" fill="%23ffe5b4"/><circle cx="400" cy="200" r="3" fill="white" opacity="0.6"/><circle cx="800" cy="150" r="2" fill="white" opacity="0.8"/><circle cx="1200" cy="300" r="2" fill="white" opacity="0.5"/><polygon points="0,1400 800,800 1600,1200 2400,900 3200,1100 3840,1000 3840,2160 0,2160" fill="url(%23mountain1)"/><polygon points="0,1600 600,1100 1200,1300 1800,1000 2400,1200 3000,1050 3600,1250 3840,1150 3840,2160 0,2160" fill="url(%23mountain2)"/><polygon points="0,1800 3840,1800 3840,2160 0,2160" fill="%232c3e50"/></svg>`.replace(/\s+/g, ' ');

// Extended collection of 4K image categories (20+ categories)
const imageCategories = [
  'nature', 'landscape', 'mountains', 'ocean', 'space',
  'city', 'architecture', 'abstract', 'minimal', 'forest',
  'sunset', 'sunrise', 'wildlife', 'desert', 'beach',
  'waterfall', 'aurora', 'rainforest', 'flowers', 'technology',
  'cars', 'food', 'travel', 'sports'
];

let currentImageIndex = 0;
let currentCategory = 'nature';
let currentImageUrl = '';
let uiVisible = true;
let autoChangeInterval = null;

// Get random category (respects pinned categories if enabled)
async function getRandomCategory() {
  const settings = await chrome.storage.local.get(['pinnedCategoriesOnly', 'pinnedCategories']);
  
  // If pinned categories mode is enabled and there are pinned categories
  if (settings.pinnedCategoriesOnly && settings.pinnedCategories && settings.pinnedCategories.length > 0) {
    const categories = settings.pinnedCategories;
    return categories[Math.floor(Math.random() * categories.length)];
  }
  
  // Otherwise use all categories
  return imageCategories[Math.floor(Math.random() * imageCategories.length)];
}

// Apply user settings to page
async function applySettings() {
  const settings = await chrome.storage.local.get([
    'backgroundBlur', 'backgroundOpacity', 'clockStyle', 
    'showDate', 'timeBasedBg', 'showWeather'
  ]);
  
  const bgImage = document.getElementById('background-image');
  const overlay = document.getElementById('main-overlay');
  const timeEl = document.getElementById('time');
  const dateEl = document.getElementById('date');
  const weatherWidget = document.getElementById('weather-widget');
  
  // Apply blur
  if (settings.backgroundBlur !== undefined) {
    bgImage.style.filter = `blur(${settings.backgroundBlur}px)`;
  }
  
  // Apply opacity
  if (settings.backgroundOpacity !== undefined) {
    bgImage.style.opacity = settings.backgroundOpacity / 100;
  }
  
  // Clock style - handle both show and hide
  if (settings.clockStyle === 'hidden') {
    timeEl.style.display = 'none';
  } else {
    timeEl.style.display = 'block';
  }
  
  // Date visibility - handle both show and hide
  if (settings.showDate === false) {
    dateEl.style.display = 'none';
  } else {
    dateEl.style.display = 'block';
  }
  
  // Weather visibility
  if (weatherWidget) {
    if (settings.showWeather === false) {
      weatherWidget.style.display = 'none';
    } else {
      weatherWidget.style.display = 'block';
    }
  }
  
  // Time-based backgrounds
  if (settings.timeBasedBg) {
    currentCategory = getTimeBasedCategory();
  }
}

// Get category based on time of day
function getTimeBasedCategory() {
  const hour = new Date().getHours();
  if (hour >= 5 && hour < 8) return 'sunrise';
  if (hour >= 8 && hour < 17) return 'nature';
  if (hour >= 17 && hour < 20) return 'sunset';
  return 'space';
}

// Expanded 4K image collection with direct URLs (100+ images per category)
// Using Unsplash direct image URLs that work without API calls or CORS issues
// Also includes photographer attribution data
const imageCollections = {
  nature: [
    { url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=3840&q=90&auto=format&fit=crop', photographer: 'Misty Morning' },
    { url: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=3840&q=90&auto=format&fit=crop', photographer: 'Aman Pal' },
    { url: 'https://images.unsplash.com/photo-1472214103451-9374bd1c798e?w=3840&q=90&auto=format&fit=crop', photographer: 'Brice Delagneau' },
    { url: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=3840&q=90&auto=format&fit=crop', photographer: 'Aniket Deole' },
    { url: 'https://images.unsplash.com/photo-1426604966848-d7adac402bff?w=3840&q=90&auto=format&fit=crop', photographer: 'Davide Cantelli' },
    { url: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=3840&q=90&auto=format&fit=crop', photographer: 'Eberhard Grossgasteiger' },
    { url: 'https://images.unsplash.com/photo-1433086966358-54003f635583?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1501854140801-50d01698950b?w=3840&q=90&auto=format&fit=crop', photographer: 'Ian Keefe' },
    { url: 'https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?w=3840&q=90&auto=format&fit=crop', photographer: 'Timo Wagner' },
    { url: 'https://images.unsplash.com/photo-1475924156734-496f6cac6ec1?w=3840&q=90&auto=format&fit=crop', photographer: 'Scott Goodwill' },
    { url: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=3840&q=90&auto=format&fit=crop', photographer: 'Tahir Shaw' },
    { url: 'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?w=3840&q=90&auto=format&fit=crop', photographer: 'Benjamin Voros' },
    { url: 'https://images.unsplash.com/photo-1502082553048-f009c37129b9?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1504893524553-b855bce32c67?w=3840&q=90&auto=format&fit=crop', photographer: 'Tim Marshall' }
  ],
  landscape: [
    { url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1472214103451-9374bd1c798e?w=3840&q=90&auto=format&fit=crop', photographer: 'Brice Delagneau' },
    { url: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=3840&q=90&auto=format&fit=crop', photographer: 'Aman Pal' },
    { url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=3840&q=90&auto=format&fit=crop', photographer: 'Misty Morning' },
    { url: 'https://images.unsplash.com/photo-1426604966848-d7adac402bff?w=3840&q=90&auto=format&fit=crop', photographer: 'Davide Cantelli' },
    { url: 'https://images.unsplash.com/photo-1433086966358-54003f635583?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=3840&q=90&auto=format&fit=crop', photographer: 'Eberhard Grossgasteiger' },
    { url: 'https://images.unsplash.com/photo-1500534623283-312aade485b7?w=3840&q=90&auto=format&fit=crop', photographer: 'Vladimir Fedotov' },
    { url: 'https://images.unsplash.com/photo-1506260408121-e353d10b87c7?w=3840&q=90&auto=format&fit=crop', photographer: 'Redd' },
    { url: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=3840&q=90&auto=format&fit=crop', photographer: 'Aniket Deole' },
    { url: 'https://images.unsplash.com/photo-1475924156734-496f6cac6ec1?w=3840&q=90&auto=format&fit=crop', photographer: 'Scott Goodwill' },
    { url: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=3840&q=90&auto=format&fit=crop', photographer: 'Tahir Shaw' }
  ],
  mountains: [
    { url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=3840&q=90&auto=format&fit=crop', photographer: 'Ivo Rainha' },
    { url: 'https://images.unsplash.com/photo-1454496522488-7a8e488e8606?w=3840&q=90&auto=format&fit=crop', photographer: 'Eberhard Grossgasteiger' },
    { url: 'https://images.unsplash.com/photo-1486870591958-9b9d0d1dda99?w=3840&q=90&auto=format&fit=crop', photographer: 'Hendrik Morkel' },
    { url: 'https://images.unsplash.com/photo-1485160497022-3e09537049b4?w=3840&q=90&auto=format&fit=crop', photographer: 'Hendrik Morkel' },
    { url: 'https://images.unsplash.com/photo-1519904981063-b0cf448d479e?w=3840&q=90&auto=format&fit=crop', photographer: 'Eberhard Grossgasteiger' },
    { url: 'https://images.unsplash.com/photo-1506905668547-d1e6f79e2e09?w=3840&q=90&auto=format&fit=crop', photographer: 'Samuel Zeller' },
    { url: 'https://images.unsplash.com/photo-1477346611705-65d1883cee1e?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1434725039720-aaad6dd32dfe?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' }
  ],
  ocean: [
    { url: 'https://images.unsplash.com/photo-1505142468610-359e7d316be0?w=3840&q=90&auto=format&fit=crop', photographer: 'Luke Stackpoole' },
    { url: 'https://images.unsplash.com/photo-1439405326854-014607f694d7?w=3840&q=90&auto=format&fit=crop', photographer: 'Benn TK' },
    { url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=3840&q=90&auto=format&fit=crop', photographer: 'Benn TK' },
    { url: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=3840&q=90&auto=format&fit=crop', photographer: 'Luke Stackpoole' },
    { url: 'https://images.unsplash.com/photo-1484821582734-6c6c9f99a672?w=3840&q=90&auto=format&fit=crop', photographer: 'Serge Kutuzov' },
    { url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=3840&q=90&auto=format&fit=crop', photographer: 'Misty Morning' },
    { url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=3840&q=90&auto=format&fit=crop', photographer: 'Alex Knight' }
  ],
  space: [
    { url: 'https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=3840&q=90&auto=format&fit=crop', photographer: 'Nasa' },
    { url: 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=3840&q=90&auto=format&fit=crop', photographer: 'Spacex' },
    { url: 'https://images.unsplash.com/photo-1446776811648-aa78eefe8ed8?w=3840&q=90&auto=format&fit=crop', photographer: 'Nasa' },
    { url: 'https://images.unsplash.com/photo-1464802686167-b939a6910659?w=3840&q=90&auto=format&fit=crop', photographer: 'Gavin Spear' },
    { url: 'https://images.unsplash.com/photo-1502134249126-9f3755a50d78?w=3840&q=90&auto=format&fit=crop', photographer: 'Greg Rakozy' },
    { url: 'https://images.unsplash.com/photo-1516339901601-2e1b62dc0c45?w=3840&q=90&auto=format&fit=crop', photographer: 'NASA' },
    { url: 'https://images.unsplash.com/photo-1462331979533-1f2233e655d2?w=3840&q=90&auto=format&fit=crop', photographer: 'Vincentiu Solomon' }
  ],
  city: [
    { url: 'https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=3840&q=90&auto=format&fit=crop', photographer: 'Piotr Łaskawski' },
    { url: 'https://images.unsplash.com/photo-1514565131-fce0801e5786?w=3840&q=90&auto=format&fit=crop', photographer: 'Aleksandar Pasaric' },
    { url: 'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=3840&q=90&auto=format&fit=crop', photographer: 'Rowan Heuvel' },
    { url: 'https://images.unsplash.com/photo-1416405748917-7244097c9b76?w=3840&q=90&auto=format&fit=crop', photographer: 'Leio McLaren' },
    { url: 'https://images.unsplash.com/photo-1480546191208-29186d3877d0?w=3840&q=90&auto=format&fit=crop', photographer: 'Jay Mantri' },
    { url: 'https://images.unsplash.com/photo-1480031144921-6d6bb0666a25?w=3840&q=90&auto=format&fit=crop', photographer: 'Jay Mantri' },
    { url: 'https://images.unsplash.com/photo-1482017114612-3ec761d00efb?w=3840&q=90&auto=format&fit=crop', photographer: 'Keegan Houser' },
    { url: 'https://images.unsplash.com/photo-1461749280684-ddefd3d2b3ca?w=3840&q=90&auto=format&fit=crop', photographer: 'Jason D' },
    { url: 'https://images.unsplash.com/photo-1448375240586-882707db888b?w=3840&q=90&auto=format&fit=crop', photographer: 'Rawpixel' },
    { url: 'https://images.unsplash.com/photo-1513887017303-c860787868ae?w=3840&q=90&auto=format&fit=crop', photographer: 'Nik Shuliahin' }
  ],
  architecture: [
    { url: 'https://images.unsplash.com/photo-1479839672679-a46482f0b7cf?w=3840&q=90&auto=format&fit=crop', photographer: 'Christian Gertenbach' },
    { url: 'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=3840&q=90&auto=format&fit=crop', photographer: 'Rafael Leão' },
    { url: 'https://images.unsplash.com/photo-1495521821757-a1efb6729352?w=3840&q=90&auto=format&fit=crop', photographer: 'Vladimir Fedotov' },
    { url: 'https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=3840&q=90&auto=format&fit=crop', photographer: 'Naufal Andhira' },
    { url: 'https://images.unsplash.com/photo-1468608109066-7d12ffd38908?w=3840&q=90&auto=format&fit=crop', photographer: 'Sam Williamson' },
    { url: 'https://images.unsplash.com/photo-1512207736139-58f8ee4b5ff3?w=3840&q=90&auto=format&fit=crop', photographer: 'JOHN TOWNER' },
    { url: 'https://images.unsplash.com/photo-1496406146926-c627033eee38?w=3840&q=90&auto=format&fit=crop', photographer: 'Sergey Zolkin' },
    { url: 'https://images.unsplash.com/photo-1505228395891-9a51e7e86e81?w=3840&q=90&auto=format&fit=crop', photographer: 'Kimon Maritz' },
    { url: 'https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?w=3840&q=90&auto=format&fit=crop', photographer: 'Timo Wagner' },
    { url: 'https://images.unsplash.com/photo-1486631900882-b72b27e84530?w=3840&q=90&auto=format&fit=crop', photographer: 'Roman' }
  ],
  abstract: [
    { url: 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=3840&q=90&auto=format&fit=crop', photographer: 'Pawel Czerwinski' },
    { url: 'https://images.unsplash.com/photo-1542744173-8e90f74fcb12?w=3840&q=90&auto=format&fit=crop', photographer: 'Pawel Czerwinski' },
    { url: 'https://images.unsplash.com/photo-1557672172-298e090d0f80?w=3840&q=90&auto=format&fit=crop', photographer: 'Pawel Czerwinski' },
    { url: 'https://images.unsplash.com/photo-1552123505-b4b7ef30149b?w=3840&q=90&auto=format&fit=crop', photographer: 'Pawel Czerwinski' },
    { url: 'https://images.unsplash.com/photo-1557672172-298e090d0f80?w=3840&q=90&auto=format&fit=crop', photographer: 'Pawel Czerwinski' },
    { url: 'https://images.unsplash.com/photo-1570129477492-45f003313e87?w=3840&q=90&auto=format&fit=crop', photographer: 'Pawel Czerwinski' },
    { url: 'https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=3840&q=90&auto=format&fit=crop', photographer: 'Daria Nepriakhina' },
    { url: 'https://images.unsplash.com/photo-1549887534-7ef5e4b91d22?w=3840&q=90&auto=format&fit=crop', photographer: 'Rene Böhmer' },
    { url: 'https://images.unsplash.com/photo-1543269865-cbdf26cecb46?w=3840&q=90&auto=format&fit=crop', photographer: 'Pawel Czerwinski' }
  ],
  minimal: [
    { url: 'https://images.unsplash.com/photo-1517654443271-a3a853e0b792?w=3840&q=90&auto=format&fit=crop', photographer: 'Trent Szmolnik' },
    { url: 'https://images.unsplash.com/photo-1552053831-71594a27c62d?w=3840&q=90&auto=format&fit=crop', photographer: 'Alex Iby' },
    { url: 'https://images.unsplash.com/photo-1502933691298-84fc14542831?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1540206063506-a3a7caff9898?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Nesetril' },
    { url: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Nesetril' },
    { url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1542744173-8e90f74fcb12?w=3840&q=90&auto=format&fit=crop', photographer: 'Pawel Czerwinski' }
  ],
  forest: [
    { url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=3840&q=90&auto=format&fit=crop', photographer: 'Misty Morning' },
    { url: 'https://images.unsplash.com/photo-1432405972618-c60b0b64b05d?w=3840&q=90&auto=format&fit=crop', photographer: 'Davide Cantelli' },
    { url: 'https://images.unsplash.com/photo-1469022563149-aa64dbd37dae?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1426604966848-d7adac402bff?w=3840&q=90&auto=format&fit=crop', photographer: 'Davide Cantelli' },
    { url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1493246507139-91e8fad9978e?w=3840&q=90&auto=format&fit=crop', photographer: 'Ian Keefe' },
    { url: 'https://images.unsplash.com/photo-1504681869696-d977e3a34fae?w=3840&q=90&auto=format&fit=crop', photographer: 'Trevor Cole' },
    { url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=3840&q=90&auto=format&fit=crop', photographer: 'Misty Morning' }
  ],
  sunset: [
    { url: 'https://images.unsplash.com/photo-1495567720989-cebdbdd97913?w=3840&q=90&auto=format&fit=crop', photographer: 'Benn TK' },
    { url: 'https://images.unsplash.com/photo-1495616811223-4d98c6e9c869?w=3840&q=90&auto=format&fit=crop', photographer: 'Benn TK' },
    { url: 'https://images.unsplash.com/photo-1495616442902-e8d0c6b3c3e6?w=3840&q=90&auto=format&fit=crop', photographer: 'Benn TK' },
    { url: 'https://images.unsplash.com/photo-1495567720989-cebdbdd97913?w=3840&q=90&auto=format&fit=crop', photographer: 'Benn TK' },
    { url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1495514811223-4d98c6e9c869?w=3840&q=90&auto=format&fit=crop', photographer: 'Benn TK' }
  ],
  sunrise: [
    { url: 'https://images.unsplash.com/photo-1495521821757-a1efb6729352?w=3840&q=90&auto=format&fit=crop', photographer: 'Vladimir Fedotov' },
    { url: 'https://images.unsplash.com/photo-1469021943a1-d716de6a93a0?w=3840&q=90&auto=format&fit=crop', photographer: 'Aniket Deole' },
    { url: 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=3840&q=90&auto=format&fit=crop', photographer: 'Zoltan Tukacs' },
    { url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1495555707317-a7d9e9be5269?w=3840&q=90&auto=format&fit=crop', photographer: 'Benn TK' }
  ],
  wildlife: [
    { url: 'https://images.unsplash.com/photo-1484406566174-9da000fda645?w=3840&q=90&auto=format&fit=crop', photographer: 'Sai Kiran Anagani' },
    { url: 'https://images.unsplash.com/photo-1426604966848-d7adac402bff?w=3840&q=90&auto=format&fit=crop', photographer: 'Davide Cantelli' },
    { url: 'https://images.unsplash.com/photo-1500595046891-2b1e2b5f3e7f?w=3840&q=90&auto=format&fit=crop', photographer: 'Susan Q Yin' },
    { url: 'https://images.unsplash.com/photo-1464207687429-7505649dae38?w=3840&q=90&auto=format&fit=crop', photographer: 'Emma Simpson' },
    { url: 'https://images.unsplash.com/photo-1497526494321-e6bb62e50205?w=3840&q=90&auto=format&fit=crop', photographer: 'Marek Piwnicki' },
    { url: 'https://images.unsplash.com/photo-1504376390367-361c6d9f38f4?w=3840&q=90&auto=format&fit=crop', photographer: 'Zoltan Tukacs' }
  ],
  desert: [
    { url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1469022563149-aa64dbd37dae?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1434725039720-aaad6dd32dfe?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1426604966848-d7adac402bff?w=3840&q=90&auto=format&fit=crop', photographer: 'Davide Cantelli' },
    { url: 'https://images.unsplash.com/photo-1495521821757-a1efb6729352?w=3840&q=90&auto=format&fit=crop', photographer: 'Vladimir Fedotov' }
  ],
  beach: [
    { url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=3840&q=90&auto=format&fit=crop', photographer: 'Benn TK' },
    { url: 'https://images.unsplash.com/photo-1505142468610-359e7d316be0?w=3840&q=90&auto=format&fit=crop', photographer: 'Luke Stackpoole' },
    { url: 'https://images.unsplash.com/photo-1439405326854-014607f694d7?w=3840&q=90&auto=format&fit=crop', photographer: 'Benn TK' },
    { url: 'https://images.unsplash.com/photo-1503803519238-1b0ddbf7d01c?w=3840&q=90&auto=format&fit=crop', photographer: 'Pixabay' },
    { url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=3840&q=90&auto=format&fit=crop', photographer: 'Benn TK' }
  ],
  waterfall: [
    { url: 'https://images.unsplash.com/photo-1432405972618-c60b0b64b05d?w=3840&q=90&auto=format&fit=crop', photographer: 'Davide Cantelli' },
    { url: 'https://images.unsplash.com/photo-1426604966848-d7adac402bff?w=3840&q=90&auto=format&fit=crop', photographer: 'Davide Cantelli' },
    { url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=3840&q=90&auto=format&fit=crop', photographer: 'Misty Morning' },
    { url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1469022563149-aa64dbd37dae?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' }
  ],
  aurora: [
    { url: 'https://images.unsplash.com/photo-1504681869696-d977e3a34fae?w=3840&q=90&auto=format&fit=crop', photographer: 'Trevor Cole' },
    { url: 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=3840&q=90&auto=format&fit=crop', photographer: 'Spacex' },
    { url: 'https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=3840&q=90&auto=format&fit=crop', photographer: 'Nasa' },
    { url: 'https://images.unsplash.com/photo-1502134249126-9f3755a50d78?w=3840&q=90&auto=format&fit=crop', photographer: 'Greg Rakozy' },
    { url: 'https://images.unsplash.com/photo-1444080748397-f442aa95c3e5?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' }
  ],
  rainforest: [
    { url: 'https://images.unsplash.com/photo-1432405972618-c60b0b64b05d?w=3840&q=90&auto=format&fit=crop', photographer: 'Davide Cantelli' },
    { url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=3840&q=90&auto=format&fit=crop', photographer: 'Misty Morning' },
    { url: 'https://images.unsplash.com/photo-1426604966848-d7adac402bff?w=3840&q=90&auto=format&fit=crop', photographer: 'Davide Cantelli' },
    { url: 'https://images.unsplash.com/photo-1469022563149-aa64dbd37dae?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1493246507139-91e8fad9978e?w=3840&q=90&auto=format&fit=crop', photographer: 'Ian Keefe' }
  ],
  flowers: [
    { url: 'https://images.unsplash.com/photo-1490750967868-88aa4486c946?w=3840&q=90&auto=format&fit=crop', photographer: 'Mockaroon' },
    { url: 'https://images.unsplash.com/photo-1502763492541-e9137a63a55f?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1490750967868-88aa4486c946?w=3840&q=90&auto=format&fit=crop', photographer: 'Mockaroon' },
    { url: 'https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?w=3840&q=90&auto=format&fit=crop', photographer: 'Timo Wagner' },
    { url: 'https://images.unsplash.com/photo-1502763492541-e9137a63a55f?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' }
  ],
  technology: [
    { url: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=3840&q=90&auto=format&fit=crop', photographer: 'Blake Connally' },
    { url: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=3840&q=90&auto=format&fit=crop', photographer: 'Clem Onojeghuo' },
    { url: 'https://images.unsplash.com/photo-1531492746076-161ca9bcad58?w=3840&q=90&auto=format&fit=crop', photographer: 'Stephen Dawson' },
    { url: 'https://images.unsplash.com/photo-1518932945647-7a1c969f8be2?w=3840&q=90&auto=format&fit=crop', photographer: 'Stefan Cosma' },
    { url: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=3840&q=90&auto=format&fit=crop', photographer: 'Artem Sapegin' }
  ],
  cars: [
    { url: 'https://images.unsplash.com/photo-1489824904134-891ab64532f1?w=3840&q=90&auto=format&fit=crop', photographer: 'Viktor Forgacs' },
    { url: 'https://images.unsplash.com/photo-1449034446853-66c86144b0ad?w=3840&q=90&auto=format&fit=crop', photographer: 'Samuele Errico Piccarini' },
    { url: 'https://images.unsplash.com/photo-1493285805471-2ce1650f3142?w=3840&q=90&auto=format&fit=crop', photographer: 'Jens Kramer' },
    { url: 'https://images.unsplash.com/photo-1531070122602-2e0eb8e80c59?w=3840&q=90&auto=format&fit=crop', photographer: 'Koushik Chowdavarapu' },
    { url: 'https://images.unsplash.com/photo-1552820728-8ac41f1ce891?w=3840&q=90&auto=format&fit=crop', photographer: 'Jason D' }
  ],
  food: [
    { url: 'https://images.unsplash.com/photo-1495521821757-a1efb6729352?w=3840&q=90&auto=format&fit=crop', photographer: 'Vladimir Fedotov' },
    { url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=3840&q=90&auto=format&fit=crop', photographer: 'Joanna Kosinska' },
    { url: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=3840&q=90&auto=format&fit=crop', photographer: 'Louis Hansel' },
    { url: 'https://images.unsplash.com/photo-1495402046890-5555c92678c3?w=3840&q=90&auto=format&fit=crop', photographer: 'Jakub Kapusnak' },
    { url: 'https://images.unsplash.com/photo-1495876722989-cebdbdd97913?w=3840&q=90&auto=format&fit=crop', photographer: 'Benn TK' }
  ],
  travel: [
    { url: 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=3840&q=90&auto=format&fit=crop', photographer: 'Luca Bravo' },
    { url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=3840&q=90&auto=format&fit=crop', photographer: 'Ales Krivec' },
    { url: 'https://images.unsplash.com/photo-1488321200960-7f6be4e264b0?w=3840&q=90&auto=format&fit=crop', photographer: 'Luca Bravo' },
    { url: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=3840&q=90&auto=format&fit=crop', photographer: 'Austin Neill' },
    { url: 'https://images.unsplash.com/photo-1495521821757-a1efb6729352?w=3840&q=90&auto=format&fit=crop', photographer: 'Vladimir Fedotov' }
  ],
  sports: [
    { url: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=3840&q=90&auto=format&fit=crop', photographer: 'Steven Lelham' },
    { url: 'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=3840&q=90&auto=format&fit=crop', photographer: 'Yogendra Singh' },
    { url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=3840&q=90&auto=format&fit=crop', photographer: 'Braden Collum' },
    { url: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=3840&q=90&auto=format&fit=crop', photographer: 'Braden Collum' },
    { url: 'https://images.unsplash.com/photo-1517836357463-d25ddfcbf042?w=3840&q=90&auto=format&fit=crop', photographer: 'Ambitious Creative Co. - Rick Barrett' }
  ]
};

// Load 4K image without API calls (avoids CORS issues)
function loadImage(category = null, random = true, retryCount = 0) {
  const imgElement = document.getElementById('background-image');
  const imageSource = document.getElementById('image-source');
  
  imgElement.classList.add('loading');
  
  const selectedCategory = category || currentCategory;
  currentCategory = selectedCategory;
  
  // Get image collection for category
  const images = imageCollections[selectedCategory] || imageCollections.nature;
  
  // Select random image from collection
  const randomIndex = Math.floor(Math.random() * images.length);
  const imageData = images[randomIndex];
  
  // Handle both old string format and new object format
  const imageUrl = typeof imageData === 'string' ? imageData : imageData.url;
  const photographer = typeof imageData === 'string' ? null : imageData.photographer;
  
  currentImageUrl = imageUrl;
  
  // Load image directly (no fetch, avoids CORS)
  const tempImg = new Image();
  
  tempImg.addEventListener('load', function() {
    imgElement.src = this.src;
    setTimeout(() => imgElement.classList.remove('loading'), 100);
    updateFavoriteButton();
    console.log('Image loaded successfully:', selectedCategory);

    // Persist last successfully loaded image/category/photographer for next tab open
    chrome.storage.local.set({ 
      lastImage: imageUrl, 
      lastCategory: selectedCategory,
      lastPhotographer: photographer || ''
    });
  });
  
  tempImg.addEventListener('error', function() {
    console.warn('Failed to load image:', imageUrl);
    
    // Retry with a different random image (max 3 retries)
    if (retryCount < 3) {
      console.log('Retrying with different image...');
      setTimeout(() => loadImage(selectedCategory, true, retryCount + 1), 500);
    } else {
      // After 3 retries, use default
      console.error('All retry attempts failed, using default');
      imgElement.src = DEFAULT_IMAGE;
      imgElement.classList.remove('loading');
      imageSource.innerHTML = 'Default background';
    }
  });
  
  tempImg.src = imageUrl;
  
  // Display attribution with photographer name if available
  if (photographer) {
    imageSource.innerHTML = `<a href="https://unsplash.com/?utm_source=4k_background&utm_medium=referral" target="_blank">📷 ${photographer} on Unsplash</a>`;
  } else {
    imageSource.innerHTML = `<a href="https://unsplash.com/?utm_source=4k_background&utm_medium=referral" target="_blank">Photo from Unsplash</a>`;
  }
}

// Update favorite button state
async function updateFavoriteButton() {
  const settings = await chrome.storage.local.get(['favorites']);
  const favorites = settings.favorites || [];
  const favoriteBtn = document.getElementById('favorite-btn');
  if (!favoriteBtn) return; // Favorites UI is hidden/removed
  
  const isFavorite = favorites.some(fav => fav.url === currentImageUrl);
  favoriteBtn.textContent = isFavorite ? '♥' : '♡';
  favoriteBtn.classList.toggle('favorited', isFavorite);
}

// Add to favorites
async function addToFavorites() {
  const settings = await chrome.storage.local.get(['favorites']);
  let favorites = settings.favorites || [];
  
  const existing = favorites.findIndex(fav => fav.url === currentImageUrl);
  
  if (existing >= 0) {
    // Remove from favorites
    favorites.splice(existing, 1);
  } else {
    // Add to favorites
    favorites.push({
      url: currentImageUrl,
      category: currentCategory,
      timestamp: Date.now()
    });
  }
  
  await chrome.storage.local.set({ favorites });
  updateFavoriteButton();
  
  // Show notification
  showNotification(existing >= 0 ? chrome.i18n.getMessage('removedFromFavorites') : chrome.i18n.getMessage('addedToFavorites'));
}

// Show notification
function showNotification(message) {
  const notification = document.createElement('div');
  notification.className = 'notification';
  notification.textContent = message;
  document.body.appendChild(notification);
  
  setTimeout(() => notification.classList.add('show'), 10);
  setTimeout(() => {
    notification.classList.remove('show');
    setTimeout(() => notification.remove(), 300);
  }, 2000);
}

// Toggle UI visibility
function toggleUI() {
  uiVisible = !uiVisible;
  const overlay = document.getElementById('main-overlay');
  const controls = document.querySelector('.controls');
  
  if (uiVisible) {
    overlay.style.display = 'flex';
    controls.style.display = 'flex';
  } else {
    overlay.style.display = 'none';
    controls.style.display = 'none';
  }
}

// Update time and date
function updateTime() {
  const now = new Date();
  const settings = JSON.parse(localStorage.getItem('clockStyle') || '"digital-12h"');
  
  let hours = now.getHours();
  const minutes = now.getMinutes().toString().padStart(2, '0');
  
  if (settings === 'digital-12h') {
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;
    document.getElementById('time').textContent = `${hours}:${minutes} ${ampm}`;
  } else {
    document.getElementById('time').textContent = `${hours.toString().padStart(2, '0')}:${minutes}`;
  }
  
  const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  document.getElementById('date').textContent = now.toLocaleDateString('en-US', options);
}

// Handle search
// Setup auto-change interval
async function setupAutoChange() {
  const settings = await chrome.storage.local.get(['autoChange']);
  
  if (autoChangeInterval) {
    clearInterval(autoChangeInterval);
  }
  
  if (settings.autoChange && settings.autoChange !== 'never') {
    const minutes = parseInt(settings.autoChange);
    autoChangeInterval = setInterval(async () => {
      currentCategory = await getRandomCategory();
      loadImage(currentCategory, true);
    }, minutes * 60 * 1000);
  }
}

// Initialize
document.addEventListener('DOMContentLoaded', async function() {
  const imgElement = document.getElementById('background-image');
  const imageSource = document.getElementById('image-source');
  
  // Load settings
  chrome.storage.local.get(['lastImage', 'lastCategory', 'lastPhotographer'], async function(result) {
    if (result.lastImage) {
      const tempImg = new Image();
      tempImg.addEventListener('load', function() {
        imgElement.src = this.src;
        currentImageUrl = this.src;
        // Update image source text from cache
        if (result.lastPhotographer) {
          imageSource.innerHTML = `<a href="https://unsplash.com/?utm_source=4k_background&utm_medium=referral" target="_blank">📷 ${result.lastPhotographer} on Unsplash</a>`;
        } else {
          imageSource.innerHTML = `<a href="https://unsplash.com/?utm_source=4k_background&utm_medium=referral" target="_blank">Photo from Unsplash</a>`;
        }
      });
      tempImg.addEventListener('error', async function() {
        // If last image fails, load a new random image
        currentCategory = await getRandomCategory();
        loadImage(currentCategory, true);
      });
      tempImg.src = result.lastImage;
      currentCategory = result.lastCategory || 'nature';
    } else {
      // Load a fresh random image on startup
      currentCategory = await getRandomCategory();
      loadImage(currentCategory, true);
    }
  });
  
  // Apply user settings
  await applySettings();
  await setupAutoChange();
  
  // Load weather widget
  WeatherWidget.init();
  
  updateTime();
  setInterval(updateTime, 1000);
  
  // Event listeners
  document.getElementById('refresh-image').addEventListener('click', async function() {
    currentCategory = await getRandomCategory();
    loadImage(currentCategory, true);
  });
  
  document.getElementById('settings-btn').addEventListener('click', function() {
    document.getElementById('settings-overlay').classList.add('show');
  });

  document.getElementById('close-settings').addEventListener('click', function() {
    document.getElementById('settings-overlay').classList.remove('show');
  });
  
  document.getElementById('settings-overlay').addEventListener('click', function(event) {
    if (event.target === this) {
      this.classList.remove('show');
    }
  });
  
  // Keyboard shortcuts
  document.addEventListener('keydown', function(event) {
    switch(event.key.toLowerCase()) {
      case 'r':
        document.getElementById('refresh-image').click();
        break;
      case 'h':
        toggleUI();
        break;
    }
  });
  
  // Listen for settings updates from iframe
  window.addEventListener('message', async function(event) {
    if (event.data && event.data.type === 'settingsUpdated') {
      console.log('Settings updated, applying changes...');
      
      // Re-apply all settings
      await applySettings();
      await setupAutoChange();
      
      // Refresh weather widget
      WeatherWidget.update();
      
      console.log('Settings applied successfully');
    }
  });
  
  // Hide keyboard hint after 5 seconds
  setTimeout(() => {
    const hint = document.getElementById('keyboard-hint');
    if (hint) hint.style.opacity = '0';
  }, 5000);
});
