// i18n helper functions
let customMessages = null;

const i18n = {
  // Load custom language messages
  loadCustomLanguage: async () => {
    try {
      const settings = await chrome.storage.local.get(['language']);
      const lang = settings.language;
      
      // If no custom language or same as browser language, use default
      if (!lang || lang === chrome.i18n.getUILanguage().replace('-', '_')) {
        customMessages = null;
        return;
      }
      
      // Load the custom language messages
      const url = chrome.runtime.getURL(`_locales/${lang}/messages.json`);
      const response = await fetch(url);
      if (response.ok) {
        customMessages = await response.json();
      }
    } catch (e) {
      console.log('Failed to load custom language:', e);
      customMessages = null;
    }
  },

  // Get translated message
  get: (key, substitutions) => {
    // Try custom messages first
    if (customMessages && customMessages[key]) {
      let message = customMessages[key].message;
      if (substitutions && Array.isArray(substitutions)) {
        substitutions.forEach((sub, i) => {
          message = message.replace(`$${i + 1}`, sub);
        });
      }
      return message;
    }
    return chrome.i18n.getMessage(key, substitutions) || key;
  },
  
  // Get browser language
  getUILanguage: () => {
    return chrome.i18n.getUILanguage();
  },
  
  // Translate all elements with data-i18n attribute
  translatePage: async () => {
    // Load custom language first
    await i18n.loadCustomLanguage();
    
    document.querySelectorAll('[data-i18n]').forEach(element => {
      const key = element.getAttribute('data-i18n');
      const translation = i18n.get(key);
      
      if (translation && translation !== key) {
        if (element.tagName === 'INPUT' && element.type !== 'checkbox') {
          element.placeholder = translation;
        } else if (element.hasAttribute('title')) {
          element.title = translation;
        } else {
          element.textContent = translation;
        }
      }
    });
    
    // Translate all elements with data-i18n-title attribute
    document.querySelectorAll('[data-i18n-title]').forEach(element => {
      const key = element.getAttribute('data-i18n-title');
      const translation = i18n.get(key);
      if (translation && translation !== key) {
        element.title = translation;
      }
    });
    
    // Translate all elements with data-i18n-placeholder attribute
    document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
      const key = element.getAttribute('data-i18n-placeholder');
      const translation = i18n.get(key);
      if (translation && translation !== key) {
        element.placeholder = translation;
      }
    });
  }
};

// Auto-translate on DOMContentLoaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => i18n.translatePage());
} else {
  i18n.translatePage();
}
