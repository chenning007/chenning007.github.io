# Icon Files

To complete the extension, you need to add PNG icons in the following sizes:
- icon16.png (16x16)
- icon48.png (48x48)
- icon128.png (128x128)

## Creating Icons

You can:
1. Convert the provided SVG file to PNG at different sizes using an online tool
2. Create custom icons using any image editor
3. Use the following online tools:
   - https://www.adobe.com/express/feature/image/resize
   - https://cloudconvert.com/svg-to-png

The icon should represent a 4K image or picture frame theme.
