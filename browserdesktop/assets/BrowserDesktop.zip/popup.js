const categories = [
  'nature',
  'landscape',
  'mountains',
  'ocean',
  'space',
  'city',
  'architecture',
  'abstract',
  'minimal',
  'forest',
  'sunset',
  'wildlife',
  'beach',
  'desert',
  'technology'
];

document.addEventListener('DOMContentLoaded', function() {
  const categoriesContainer = document.getElementById('categories');
  
  categories.forEach(category => {
    const btn = document.createElement('button');
    btn.className = 'category-btn';
    btn.textContent = category;
    btn.addEventListener('click', function() {
      // Save selected category
      chrome.storage.local.set({ 
        lastCategory: category,
        lastUpdate: Date.now()
      }, function() {
        // Show feedback
        btn.textContent = '✓ ' + category;
        setTimeout(() => {
          btn.textContent = category;
        }, 1000);
      });
    });
    categoriesContainer.appendChild(btn);
  });
});
