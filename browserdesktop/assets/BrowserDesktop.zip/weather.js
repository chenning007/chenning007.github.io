// ============================================
// Weather Widget Module
// ============================================

const WeatherWidget = (function() {
  // Weather icon mapping based on condition codes
  const weatherIcons = {
    '01d': '☀️', '01n': '🌙',  // clear
    '02d': '⛅', '02n': '☁️',  // few clouds
    '03d': '☁️', '03n': '☁️',  // scattered clouds
    '04d': '☁️', '04n': '☁️',  // broken clouds
    '09d': '🌧️', '09n': '🌧️', // shower rain
    '10d': '🌦️', '10n': '🌧️', // rain
    '11d': '⛈️', '11n': '⛈️',  // thunderstorm
    '13d': '❄️', '13n': '❄️',  // snow
    '50d': '🌫️', '50n': '🌫️'  // mist
  };

  // Get coordinates from city name using Open-Meteo geocoding
  async function getCoordinatesFromCity(cityName) {
    const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(cityName)}&count=1&language=en&format=json`;
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.results && data.results.length > 0) {
      const result = data.results[0];
      return {
        lat: result.latitude,
        lon: result.longitude,
        city: result.name
      };
    }
    throw new Error('City not found');
  }

  // Get user's location (fallback when no city is set)
  async function getUserLocation() {
    // First try browser geolocation
    try {
      const position = await new Promise((resolve, reject) => {
        if (!navigator.geolocation) {
          reject(new Error('Geolocation not supported'));
          return;
        }
        
        navigator.geolocation.getCurrentPosition(
          position => resolve({
            lat: position.coords.latitude,
            lon: position.coords.longitude
          }),
          error => {
            const errorMessages = {
              1: 'Location permission denied',
              2: 'Location unavailable',
              3: 'Location request timed out'
            };
            reject(new Error(errorMessages[error.code] || 'Unknown location error'));
          },
          { timeout: 5000, enableHighAccuracy: false }
        );
      });
      return position;
    } catch (geoError) {
      console.log('Browser geolocation failed, trying IP-based location...');
      
      // Fallback to IP-based geolocation
      try {
        const response = await fetch('https://ipapi.co/json/');
        const data = await response.json();
        if (data.latitude && data.longitude) {
          return {
            lat: data.latitude,
            lon: data.longitude,
            city: data.city
          };
        }
        throw new Error('IP geolocation failed');
      } catch (ipError) {
        console.error('IP geolocation also failed:', ipError);
        throw geoError;
      }
    }
  }

  // Fetch weather data using Open-Meteo (free, no API key required)
  async function fetchWeather(lat, lon, knownCity = null) {
    try {
      // Get weather data from Open-Meteo
      const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,weather_code&timezone=auto`;
      const weatherResponse = await fetch(weatherUrl);
      const weatherData = await weatherResponse.json();
      
      let city = knownCity;
      
      // Only do reverse geocoding if we don't already have the city name
      if (!city) {
        try {
          const geoUrl = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json`;
          const geoResponse = await fetch(geoUrl, {
            headers: { 'User-Agent': 'BrowserDesktop/1.0' }
          });
          const geoData = await geoResponse.json();
          city = geoData.address?.city || geoData.address?.town || geoData.address?.village || geoData.address?.county || 'Unknown';
        } catch (geoError) {
          console.log('Reverse geocoding failed, using coordinates');
          city = `${lat.toFixed(1)}°, ${lon.toFixed(1)}°`;
        }
      }
      
      return {
        temp: Math.round(weatherData.current.temperature_2m),
        code: weatherData.current.weather_code,
        city: city,
        lat: lat,
        lon: lon
      };
    } catch (error) {
      console.error('Weather fetch error:', error);
      throw error;
    }
  }

  // Map Open-Meteo weather codes to icons
  function getWeatherIcon(code, isDay = true) {
    const suffix = isDay ? 'd' : 'n';
    
    // WMO Weather codes mapping
    if (code === 0) return weatherIcons['01' + suffix]; // Clear
    if (code <= 3) return weatherIcons['02' + suffix]; // Partly cloudy
    if (code <= 49) return weatherIcons['50' + suffix]; // Fog/mist
    if (code <= 59) return weatherIcons['09' + suffix]; // Drizzle
    if (code <= 69) return weatherIcons['10' + suffix]; // Rain
    if (code <= 79) return weatherIcons['13' + suffix]; // Snow
    if (code <= 84) return weatherIcons['09' + suffix]; // Rain showers
    if (code <= 94) return weatherIcons['13' + suffix]; // Snow showers
    if (code >= 95) return weatherIcons['11' + suffix]; // Thunderstorm
    
    return '🌡️';
  }

  // Open weather website for the current city
  function openWeatherWebsite(city, lat, lon) {
    let url;
    if (lat && lon) {
      // Use yr.no (Norwegian Meteorological Institute) - excellent free weather with coordinate support
      url = `https://www.yr.no/en/forecast/daily-table/${lat.toFixed(4)},${lon.toFixed(4)}`;
    } else if (city && city !== 'Unknown') {
      // Search on yr.no
      url = `https://www.yr.no/en/search?q=${encodeURIComponent(city)}`;
    } else {
      url = 'https://www.yr.no/en';
    }
    window.open(url, '_blank');
  }

  // Store current weather data for click handler
  let currentWeatherData = null;

  // Open settings panel and navigate to weather section
  function openWeatherSettings() {
    // Show settings overlay
    const settingsOverlay = document.getElementById('settings-overlay');
    if (settingsOverlay) {
      settingsOverlay.classList.add('show');
      
      // Wait for iframe to be ready, then navigate to weather section
      const iframe = settingsOverlay.querySelector('.settings-frame');
      if (iframe && iframe.contentWindow) {
        // Try to navigate immediately and also after a short delay for reliability
        const navigateToWeather = () => {
          try {
            iframe.contentWindow.postMessage({ type: 'navigateToSection', section: 'weather' }, '*');
          } catch (e) {
            console.log('Could not post message to iframe');
          }
        };
        
        navigateToWeather();
        setTimeout(navigateToWeather, 100);
      }
    }
  }

  // Initialize weather settings button
  function initSettingsButton() {
    const settingsBtn = document.getElementById('weather-settings-btn');
    
    if (settingsBtn && !settingsBtn.dataset.listenerAdded) {
      settingsBtn.addEventListener('click', (e) => {
        e.stopPropagation(); // Prevent triggering weather widget click
        openWeatherSettings();
      });
      settingsBtn.dataset.listenerAdded = 'true';
    }
  }

  // Current city index for cycling through multiple cities
  let currentCityIndex = 0;
  let allCitiesWeather = [];

  // Update weather widget
  async function update(cycleToNext = false) {
    const widget = document.getElementById('weather-widget');
    const tempEl = document.getElementById('weather-temp');
    const cityEl = document.getElementById('weather-city');
    const iconEl = document.getElementById('weather-icon');
    
    if (!widget) return;
    
    // Check if weather is enabled - support both old and new format
    const settings = await chrome.storage.local.get(['showWeather', 'weatherCities', 'weatherCity', 'tempUnit', 'weatherCityIndex']);
    
    if (settings.showWeather === false) {
      widget.style.display = 'none';
      return;
    }
    widget.style.display = 'flex';
    
    // Get cities list (support legacy single city format)
    let cities = settings.weatherCities || [];
    if (cities.length === 0 && settings.weatherCity) {
      cities = [{ name: settings.weatherCity }];
    }
    
    // Handle cycling
    if (cycleToNext && cities.length > 1) {
      currentCityIndex = (currentCityIndex + 1) % cities.length;
      await chrome.storage.local.set({ weatherCityIndex: currentCityIndex });
    } else if (settings.weatherCityIndex !== undefined) {
      currentCityIndex = settings.weatherCityIndex % Math.max(1, cities.length);
    }
    
    widget.classList.add('loading');
    
    try {
      const now = Date.now();
      const cached = await chrome.storage.local.get(['weatherCacheMulti', 'weatherCacheTime']);
      
      // Use cached data if available and fresh
      if (cached.weatherCacheMulti && 
          cached.weatherCacheTime && 
          (now - cached.weatherCacheTime < 30 * 60 * 1000)) {
        allCitiesWeather = cached.weatherCacheMulti;
      } else {
        // Fetch weather for all cities
        allCitiesWeather = [];
        
        if (cities.length === 0) {
          // Auto-detect location if no cities configured
          const location = await getUserLocation();
          const weather = await fetchWeather(location.lat, location.lon, location.city);
          allCitiesWeather.push(weather);
        } else {
          for (const city of cities) {
            try {
              let location;
              if (city.lat && city.lon) {
                location = { lat: city.lat, lon: city.lon, city: city.name };
              } else {
                location = await getCoordinatesFromCity(city.name);
              }
              const weather = await fetchWeather(location.lat, location.lon, location.city);
              allCitiesWeather.push(weather);
            } catch (err) {
              console.log(`Weather fetch failed for ${city.name}:`, err.message);
              allCitiesWeather.push({ city: city.name, temp: null, code: null, error: true });
            }
          }
        }
        
        // Cache results
        await chrome.storage.local.set({
          weatherCacheMulti: allCitiesWeather,
          weatherCacheTime: now
        });
      }
      
      // Display current city's weather
      if (allCitiesWeather.length > 0) {
        const idx = currentCityIndex % allCitiesWeather.length;
        const data = allCitiesWeather[idx];
        currentWeatherData = data;
        
        if (data.error || data.temp === null) {
          tempEl.textContent = '--°';
          iconEl.textContent = '🌡️';
        } else {
          const hour = new Date().getHours();
          const isDay = hour >= 6 && hour < 20;
          const temp = settings.tempUnit === 'fahrenheit' ? Math.round(data.temp * 9/5 + 32) : data.temp;
          const unit = settings.tempUnit === 'fahrenheit' ? '°F' : '°C';
          tempEl.textContent = `${temp}${unit}`;
          iconEl.textContent = getWeatherIcon(data.code, isDay);
        }
        
        // Show city name with indicator if multiple cities
        if (allCitiesWeather.length > 1) {
          cityEl.textContent = `${data.city} (${idx + 1}/${allCitiesWeather.length})`;
        } else {
          cityEl.textContent = data.city;
        }
      }
      
    } catch (error) {
      console.log('Weather unavailable:', error.message);
      tempEl.textContent = '--°';
      cityEl.textContent = 'Set city in settings';
      iconEl.textContent = '🌡️';
    }
    
    widget.classList.remove('loading');
  }

  // Cycle to next city
  function cycleCity() {
    update(true);
  }

  // Initialize widget with click handler
  function init() {
    const widget = document.getElementById('weather-widget');
    if (widget) {
      // Only add click listener if not already added
      if (!widget.dataset.listenerAdded) {
        widget.addEventListener('click', (e) => {
          // Don't open weather site if clicking settings button
          if (e.target.id === 'weather-settings-btn') return;
          
          // Cycle to next city if multiple cities
          if (allCitiesWeather.length > 1) {
            cycleCity();
          } else if (currentWeatherData) {
            openWeatherWebsite(currentWeatherData.city, currentWeatherData.lat, currentWeatherData.lon);
          } else {
            window.open('https://www.weather.com', '_blank');
          }
        });
        widget.dataset.listenerAdded = 'true';
      }
      widget.title = 'Click to cycle cities';
    }
    
    // Initialize settings button
    initSettingsButton();
    
    update();
  }

  // Public API
  return {
    init: init,
    update: update,
    cycleCity: cycleCity
  };
})();
