// Default settings
const DEFAULT_SETTINGS = {
  backgroundBlur: 0,
  backgroundOpacity: 100,
  clockStyle: 'digital-12h',
  showDate: true,
  showSearch: true,
  autoChange: 'never',
  timeBasedBg: false,
  pinnedCategoriesOnly: false,
  pinnedCategories: [],
  showQuickLinks: true,
  quickLinksCount: 8,
  language: 'en',
  showWeather: true,
  weatherCities: [],
  tempUnit: 'celsius',
  favorites: [],
  quickLinks: [
    { url: 'https://github.com', name: 'GitHub', favicon: 'https://github.com/favicon.ico' },
    { url: 'https://stackoverflow.com', name: 'Stack Overflow', favicon: 'https://stackoverflow.com/favicon.ico' },
    { url: 'https://gmail.com', name: 'Gmail', favicon: 'https://gmail.com/favicon.ico' },
    { url: 'https://youtube.com', name: 'YouTube', favicon: 'https://youtube.com/favicon.ico' },
    { url: 'https://twitter.com', name: 'Twitter', favicon: 'https://twitter.com/favicon.ico' },
    { url: 'https://reddit.com', name: 'Reddit', favicon: 'https://reddit.com/favicon.ico' },
    { url: 'https://linkedin.com', name: 'LinkedIn', favicon: 'https://linkedin.com/favicon.ico' },
    { url: 'https://amazon.com', name: 'Amazon', favicon: 'https://amazon.com/favicon.ico' }
  ]
};

// Available categories
const imageCategories = [
  'nature', 'landscape', 'mountains', 'ocean', 'space',
  'city', 'architecture', 'abstract', 'minimal', 'forest',
  'sunset', 'sunrise', 'wildlife', 'desert', 'beach',
  'waterfall', 'aurora', 'rainforest', 'flowers', 'technology',
  'cars', 'food', 'travel', 'sports'
];

// Load current settings
async function loadSettings() {
  const settings = await chrome.storage.local.get(DEFAULT_SETTINGS);
  
  // Appearance
  document.getElementById('background-blur').value = settings.backgroundBlur;
  document.getElementById('blur-value').textContent = `${settings.backgroundBlur}px`;
  document.getElementById('background-opacity').value = settings.backgroundOpacity;
  document.getElementById('opacity-value').textContent = `${settings.backgroundOpacity}%`;
  document.getElementById('clock-style').value = settings.clockStyle;
  document.getElementById('show-date').checked = settings.showDate;
  document.getElementById('show-search').checked = settings.showSearch;
  
  // Background
  document.getElementById('auto-change').value = settings.autoChange;
  document.getElementById('time-based-bg').checked = settings.timeBasedBg;
  document.getElementById('pinned-categories-only').checked = settings.pinnedCategoriesOnly;
  
  // Quick Links
  document.getElementById('show-quick-links').checked = settings.showQuickLinks;
  document.getElementById('quick-links-count').value = settings.quickLinksCount;
  
  // Language
  document.getElementById('language-select').value = settings.language || 'en';
  
  // Weather
  document.getElementById('show-weather').checked = settings.showWeather !== false;
  document.getElementById('temp-unit').value = settings.tempUnit || 'celsius';
  
  // Load cities list (support legacy weatherCity as well)
  let cities = settings.weatherCities || [];
  if (cities.length === 0 && settings.weatherCity) {
    // Migrate from old single city format
    cities = [{ name: settings.weatherCity, country: '' }];
  }
  loadCitiesList(cities);
  
  // Pinned Categories
  loadPinnedCategories(settings.pinnedCategories || []);
  
  // Favorites
  loadFavorites(settings.favorites || []);
}

// Load pinned categories
function loadPinnedCategories(pinnedCategories = []) {
  const grid = document.getElementById('categories-grid');
  
  grid.innerHTML = imageCategories.map(category => {
    const isPinned = pinnedCategories.includes(category);
    // Translate category name (e.g., "nature" -> "categoryNature" -> "Nature")
    const categoryKey = 'category' + category.charAt(0).toUpperCase() + category.slice(1);
    const translatedName = i18n.get(categoryKey) || category;
    return `
      <div class="category-tag ${isPinned ? 'pinned' : ''}" data-category="${category}">
        ${translatedName}
      </div>
    `;
  }).join('');
  
  // Add click event listeners
  document.querySelectorAll('.category-tag').forEach(tag => {
    tag.addEventListener('click', function() {
      this.classList.toggle('pinned');
    });
  });
}

// Load favorites display
function loadFavorites(favorites) {
  const favoritesList = document.getElementById('favorites-list');
  
  if (!favorites || favorites.length === 0) {
    favoritesList.innerHTML = `<p class="empty-state">${chrome.i18n.getMessage('noFavorites')}</p>`;
    return;
  }
  
  const removeText = chrome.i18n.getMessage('remove');
  favoritesList.innerHTML = favorites.map((fav, index) => `
    <div class="favorite-item">
      <img src="${fav.url}" alt="${fav.category}">
      <span class="category">${fav.category}</span>
      <button class="remove-favorite-btn" data-index="${index}">${removeText}</button>
    </div>
  `).join('');
  
  // Add event listeners to remove buttons
  document.querySelectorAll('.remove-favorite-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const index = parseInt(e.target.getAttribute('data-index'));
      await removeFavorite(index);
    });
  });
}

// Weather cities list
let weatherCities = [];

function loadCitiesList(cities) {
  weatherCities = cities || [];
  renderCitiesList();
}

function renderCitiesList() {
  const list = document.getElementById('cities-list');
  if (!list) return;
  
  if (weatherCities.length === 0) {
    list.innerHTML = '<div class="cities-empty">No cities added. Add a city above.</div>';
    return;
  }
  
  list.innerHTML = weatherCities.map((city, index) => `
    <div class="city-item" data-index="${index}">
      <div class="city-info">
        <span class="city-name">${city.name}</span>
        ${city.country ? `<span class="city-country">${city.country}</span>` : ''}
      </div>
      <button type="button" class="remove-city-btn" data-index="${index}" title="Remove">&times;</button>
    </div>
  `).join('');
  
  // Add remove listeners
  list.querySelectorAll('.remove-city-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const index = parseInt(btn.dataset.index);
      removeCity(index);
    });
  });
}

function addCity(cityData) {
  // Check if city already exists
  const exists = weatherCities.some(c => 
    c.name.toLowerCase() === cityData.name.toLowerCase() && 
    c.country === cityData.country
  );
  
  if (!exists) {
    weatherCities.push(cityData);
    renderCitiesList();
  }
}

function removeCity(index) {
  weatherCities.splice(index, 1);
  renderCitiesList();
}

// Remove favorite
async function removeFavorite(index) {
  const settings = await chrome.storage.local.get(['favorites']);
  const favorites = settings.favorites || [];
  favorites.splice(index, 1);
  await chrome.storage.local.set({ favorites });
  loadFavorites(favorites);
}

// Clear all favorites
document.getElementById('clear-favorites')?.addEventListener('click', async () => {
  if (confirm(chrome.i18n.getMessage('confirmClearFavorites'))) {
    await chrome.storage.local.set({ favorites: [] });
    loadFavorites([]);
  }
});

// Update slider values display
document.getElementById('background-blur')?.addEventListener('input', (e) => {
  document.getElementById('blur-value').textContent = `${e.target.value}px`;
});

document.getElementById('background-opacity')?.addEventListener('input', (e) => {
  document.getElementById('opacity-value').textContent = `${e.target.value}%`;
});

// Save settings
document.getElementById('save-settings')?.addEventListener('click', async () => {
  try {
    // Get pinned categories
    const pinnedCategories = Array.from(document.querySelectorAll('.category-tag.pinned'))
      .map(tag => tag.getAttribute('data-category'));
    
    console.log('Saving pinned categories:', pinnedCategories);
    
    const settings = {
      backgroundBlur: parseInt(document.getElementById('background-blur').value),
      backgroundOpacity: parseInt(document.getElementById('background-opacity').value),
      clockStyle: document.getElementById('clock-style').value,
      showDate: document.getElementById('show-date').checked,
      showSearch: document.getElementById('show-search').checked,
      autoChange: document.getElementById('auto-change').value,
      timeBasedBg: document.getElementById('time-based-bg').checked,
      pinnedCategoriesOnly: document.getElementById('pinned-categories-only').checked,
      pinnedCategories: pinnedCategories,
      showQuickLinks: document.getElementById('show-quick-links').checked,
      quickLinksCount: parseInt(document.getElementById('quick-links-count').value),
      language: document.getElementById('language-select').value,
      showWeather: document.getElementById('show-weather').checked,
      weatherCities: weatherCities,
      tempUnit: document.getElementById('temp-unit').value
    };
    
    // Keep existing favorites and quick links
    const existing = await chrome.storage.local.get(['favorites', 'quickLinks']);
    settings.favorites = existing.favorites || DEFAULT_SETTINGS.favorites;
    settings.quickLinks = existing.quickLinks || DEFAULT_SETTINGS.quickLinks;
    
    // Clear weather cache if cities changed
    const oldSettings = await chrome.storage.local.get(['weatherCities']);
    const oldCitiesStr = JSON.stringify(oldSettings.weatherCities || []);
    const newCitiesStr = JSON.stringify(weatherCities);
    if (oldCitiesStr !== newCitiesStr) {
      await chrome.storage.local.remove(['weatherCache', 'weatherCacheTime', 'weatherCacheCity', 'weatherCityIndex']);
    }
    
    await chrome.storage.local.set(settings);
    console.log('Settings saved successfully:', settings);
    
    // Notify parent window to apply settings immediately
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({ type: 'settingsUpdated', settings: settings }, '*');
    }
    
    // Show success message
    const button = document.getElementById('save-settings');
    const originalText = button.textContent;
    button.textContent = '✓';
    button.style.background = '#28a745';
    setTimeout(() => {
      button.textContent = originalText;
      button.style.background = '';
    }, 2000);
  } catch (error) {
    console.error('Error saving settings:', error);
    alert('Error saving settings: ' + error.message);
  }
});

// Reset to defaults
document.getElementById('reset-settings')?.addEventListener('click', async () => {
  if (confirm(chrome.i18n.getMessage('confirmReset'))) {
    await chrome.storage.local.set(DEFAULT_SETTINGS);
    location.reload();
  }
});

// Export settings
document.getElementById('export-settings')?.addEventListener('click', async () => {
  const settings = await chrome.storage.local.get();
  const dataStr = JSON.stringify(settings, null, 2);
  const dataBlob = new Blob([dataStr], { type: 'application/json' });
  const url = URL.createObjectURL(dataBlob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `4k-background-settings-${Date.now()}.json`;
  link.click();
  URL.revokeObjectURL(url);
});

// Import settings
document.getElementById('import-settings')?.addEventListener('click', () => {
  document.getElementById('import-file').click();
});

document.getElementById('import-file')?.addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  
  const reader = new FileReader();
  reader.onload = async (event) => {
    try {
      const settings = JSON.parse(event.target.result);
      await chrome.storage.local.set(settings);
      alert(chrome.i18n.getMessage('settingsImported'));
      location.reload();
    } catch (error) {
      alert(chrome.i18n.getMessage('importError'));
    }
  };
  reader.readAsText(file);
});

// Sidebar Navigation
function initSidebarNavigation() {
  document.querySelectorAll('.menu-item').forEach(item => {
    item.addEventListener('click', () => {
      // Remove active from all menu items
      document.querySelectorAll('.menu-item').forEach(i => i.classList.remove('active'));
      // Remove active from all sections
      document.querySelectorAll('.settings-section').forEach(s => s.classList.remove('active'));
      
      // Add active to clicked item
      item.classList.add('active');
      
      // Show corresponding section
      const section = item.dataset.section;
      const panel = document.getElementById('section-' + section);
      if (panel) {
        panel.classList.add('active');
      }
    });
  });
}

// Navigate to a specific section programmatically
function navigateToSection(sectionName) {
  const menuItem = document.querySelector(`.menu-item[data-section="${sectionName}"]`);
  if (menuItem) {
    menuItem.click();
  }
}

// Listen for navigation messages from parent window
window.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'navigateToSection') {
    navigateToSection(event.data.section);
  }
});

// City Autocomplete
function initCityAutocomplete() {
  const input = document.getElementById('weather-city-input');
  const dropdown = document.getElementById('city-autocomplete');
  const addBtn = document.getElementById('add-city-btn');
  
  if (!input || !dropdown) return;
  
  let debounceTimer = null;
  let selectedIndex = -1;
  let currentResults = [];
  let selectedCity = null;
  
  // Fetch city suggestions from Open-Meteo geocoding API
  async function fetchCitySuggestions(query) {
    if (query.length < 2) {
      hideDropdown();
      return;
    }
    
    dropdown.innerHTML = '<div class="autocomplete-loading">Searching...</div>';
    dropdown.classList.add('show');
    
    try {
      const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=8&language=en&format=json`;
      const response = await fetch(url);
      const data = await response.json();
      
      if (data.results && data.results.length > 0) {
        currentResults = data.results;
        renderResults(data.results);
      } else {
        currentResults = [];
        dropdown.innerHTML = '<div class="autocomplete-no-results">No cities found</div>';
      }
    } catch (error) {
      console.error('City search error:', error);
      dropdown.innerHTML = '<div class="autocomplete-no-results">Search failed</div>';
    }
  }
  
  // Render search results
  function renderResults(results) {
    selectedIndex = -1;
    dropdown.innerHTML = results.map((city, index) => {
      const region = [city.admin1, city.country].filter(Boolean).join(', ');
      return `
        <div class="autocomplete-item" data-index="${index}">
          <div class="city-name">${city.name}</div>
          <div class="city-region">${region}</div>
        </div>
      `;
    }).join('');
    
    // Add click listeners
    dropdown.querySelectorAll('.autocomplete-item').forEach(item => {
      item.addEventListener('click', () => {
        const idx = parseInt(item.dataset.index);
        selectCity(currentResults[idx]);
      });
    });
  }
  
  // Select a city (just fills the input, doesn't add yet)
  function selectCity(city) {
    input.value = city.name;
    selectedCity = {
      name: city.name,
      country: city.country || '',
      lat: city.latitude,
      lon: city.longitude
    };
    hideDropdown();
  }
  
  // Add the selected city to the list
  function addSelectedCity() {
    if (selectedCity) {
      addCity(selectedCity);
      input.value = '';
      selectedCity = null;
    } else if (input.value.trim()) {
      // If user typed without selecting, add as plain text
      addCity({ name: input.value.trim(), country: '' });
      input.value = '';
    }
  }
  
  // Hide dropdown
  function hideDropdown() {
    dropdown.classList.remove('show');
    dropdown.innerHTML = '';
    currentResults = [];
    selectedIndex = -1;
  }
  
  // Handle keyboard navigation
  function updateSelection() {
    const items = dropdown.querySelectorAll('.autocomplete-item');
    items.forEach((item, idx) => {
      item.classList.toggle('selected', idx === selectedIndex);
    });
    
    // Scroll selected item into view
    if (selectedIndex >= 0 && items[selectedIndex]) {
      items[selectedIndex].scrollIntoView({ block: 'nearest' });
    }
  }
  
  // Input event - debounced search
  input.addEventListener('input', (e) => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      fetchCitySuggestions(e.target.value.trim());
    }, 300);
  });
  
  // Keyboard navigation
  input.addEventListener('keydown', (e) => {
    const items = dropdown.querySelectorAll('.autocomplete-item');
    
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (currentResults.length > 0) {
        selectedIndex = Math.min(selectedIndex + 1, currentResults.length - 1);
        updateSelection();
      }
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (currentResults.length > 0) {
        selectedIndex = Math.max(selectedIndex - 1, 0);
        updateSelection();
      }
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (selectedIndex >= 0 && currentResults[selectedIndex]) {
        selectCity(currentResults[selectedIndex]);
        // Add the city immediately when pressing Enter on a selection
        addSelectedCity();
      } else if (selectedCity || input.value.trim()) {
        // Add the city if one is selected or typed
        addSelectedCity();
      }
    } else if (e.key === 'Escape') {
      hideDropdown();
    }
  });
  
  // Add button click
  if (addBtn) {
    addBtn.addEventListener('click', addSelectedCity);
  }
  
  // Hide dropdown when clicking outside
  document.addEventListener('click', (e) => {
    if (!input.contains(e.target) && !dropdown.contains(e.target)) {
      hideDropdown();
    }
  });
  
  // Show dropdown on focus if there's text
  input.addEventListener('focus', () => {
    if (input.value.trim().length >= 2 && currentResults.length === 0) {
      fetchCitySuggestions(input.value.trim());
    }
  });
  
  // Clear selected city when input changes
  input.addEventListener('input', () => {
    selectedCity = null;
  });
}

// Initialize
initSidebarNavigation();
initCityAutocomplete();

// Wait for i18n to load custom language, then load settings
(async function() {
  await i18n.loadCustomLanguage();
  await loadSettings();
})();
